# Voice — final shared source contract

Read-only Figma capture, 2026-10-08, file `af4yDqCzp57jds9lkFiIaO`. This supersedes `shared-refresh` pending bindings/overflow/icon findings. Parent reports final freeze; live reads below verify the resulting source. Preserve earlier evidence, do not edit Figma.

## Canonical identities and composition

- Shared `VoiceControlsContent` **2217:1571** is a COMPONENT on Compositions826:482, Shared content2217:1551, **370×914**, vertical gap24. `Show conversation entry#2217:0`: BOOLEAN defaulttrue, controls entire Section2217:1554. Core height is content measurement, not a fixed screen height. Earlier overflowing footer is corrected: child section heights74/132/136/500 + three24 gaps =914.
- Shared `VoiceChooserContent` **2217:1901** is COMPONENT, **370×450**, no exposed properties. Intro40 + gap24 + rows322 + gap24 + footer40. Stateful labels/icons/accessories are nested overrides in source; code should expose controlled inputs/callbacks.
- Settings screen set **1904:56535**, Menu=Closed1904:56533 / Menu=Open1904:56534, each402×874. Core instances2219:9878 /2219:10173 both show conversation entry=true.
- Settings chooser **1882:42599** is FRAME402×874 with core instance2219:10323. It is a separate navigated screen with Back and title `Choose a voice`.
- Onboarding New2213:9168 has six canonical Controls consumers:2219:22520 default,2219:22800 preview,2219:23081 selected,2219:23361 speed adjusted,2219:23641 consistency adjusted,2219:23921 likeness adjusted. All hide conversation entry=false, core reflows to370×758. Three chooser masters2221:83686 default,2221:83798 preview,2221:84017 selected use2217:1901. Connected-flow miniature instances are not extra canonical screens.
- Shell owns title/lockup, scrolling, safe areas, fixed bottom actions and context-specific state. Settings uses native SwiftUI List/Section/native controls; Compose uses shared RemSection/native Material controls. Do not reproduce onboarding's Continue/Skip group in Settings or duplicate shared cores by context.

## Exact shared copy and fixtures

Preview: **Hear this voice** / **Aria**. Previewing specimen changes secondary line to **Aria · Playing**. Selected specimen changes to **Sol**.

Conversation entry: **Center button starts** → default **Voice session**. Native menu choices **Voice session**, **Chat**. Footer: `Choose whether the center action opens a voice session or a new chat.` This changes only the local chosen center-action preference; it does not launch a microphone/session/chat from Settings.

Spoken responses: **Voice** / default **Aria (Warm)**, selected specimen **Sol (Bright)**. Footer: `Choose how Rem sounds when reading a response or talking with you.` Row opens the chooser.

Character & speed:

| Control | Minimum copy | Maximum copy | Default normalized fixture | Authored adjusted specimen |
|---|---|---|---|---|
| Speed | Slower | Faster |0.50|0.75 at2219:23361|
| Consistency | Creative | Consistent |0.75|0.50 at2219:23641|
| Likeness | Flexible | Faithful |0.50|0.75 at2219:23921|

Source exposes percentages, not provider units/min-max speeds. Use normalized0…1 fixture values; do not invent service ranges. Source Speed/Likeness default show ticks; Consistency does not. Slider content1375:5915,50% variant1046:23,75%1046:22, native implementation may use the platform slider.

Footer: `Speed applies to the next thing Rem says. Consistency trades expressive range for a steadier delivery, and likeness controls how closely Rem holds to the chosen voice.` It wraps naturally to72pt at338pt text width; do not reuse old32pt footer height.

Chooser intro: `Preview a voice, then choose the one Rem should use.` Exact ordered voices:

| ID | Name | Description |
|---|---|---|
| aria | Aria | Warm |
| sol | Sol | Bright |
| rowan | Rowan | Calm |
| juniper | Juniper | Expressive |
| vale | Vale | Neutral |

Chooser footer: `Your choice follows this agent across your devices. Tap a play button to hear a preview.` This is authored copy; prototype state remains local and performs no sync.

## Canonical components, icons, geometry

Section741:311 Inset Grouped; ListRow101:18; ListRowLabel188:2. Preview row1328:26731,48×48 Accent icon Button1328:367 (blue with white play/pause) is intentional action emphasis.

Conversation entry leading icon is speaker (`􀊠`); Voice is waveform (`􀙫`). Both use29×29 **ContainedIcon614:4 Style=Subtle, Size=Small**, primary glyph. Chooser all five leading play/pause icons now also use **614:4**, primary glyph; previous Tinted/blue-play treatment in shared-refresh is superseded. Native SF `play.fill` (`􀊄`), `pause.fill` (`􀊆`) and semantic Material counterparts; no rasterized Figma glyph assets.

Chooser rows are368×64 inside370×322 section. Selection accessory is **28×24 hugging**, main1900:9597 Symbol=Checkmark circle selected blue; main1900:9595 Symbol=Circle unselected secondary. Preserve blue selected check as an intentional semantic exception. Avoid forcing these into disclosure13pt width. Source selected Sol has unselected Aria circle and blue Sol check; default selects Aria.

## Interactions and explicit limits

Source screens have no configured Figma reactions; the following wiring is the minimal prototype interpretation of authored state specimens, not recorded interaction metadata:

- Preference menu selection closes menu and updates the local value. Dismissal preserves value; Back at Settings root returns Agent settings.
- Voice row pushes chooser. Selecting a voice updates its checkmark **while staying on the chooser**, as selected2221:84017 shows. Back returns to Controls and updates both preview and Voice row labels. No save/cancel toolbar is authored for chooser.
- Preview and selection are separate targets/actions. Tap play toggles one local previewing voice; pause stops. Chooser preview specimen2221:83798 has **Aria still selected**, only Aria leading symbol changed to pause. Preview must not select a different voice.
- No supplied audio recordings/provider API. Simulated preview state is permitted, with no real microphone, TTS, account sync or service action. Any first-preview disclosure dialog is a product-boundary adaptation, **not Figma-authored copy**; coordinate with root. Do not insert a persistent unapproved warning into the designed content.
- Sliders update local values independently. Back/return within the destination session should preserve committed fixture selections; navigating away should stop simulated preview.

## Evidence

High-fidelity `.txt` context and `.png` renders named by node IDs are in this folder for cores, Settings closed/open/chooser and all captured onboarding state specimens. `voice-structure.json`, `voice-bindings.json`, `onboarding-voice.json`, `voice-states.json` preserve exact properties, ancestry, defaults, selector geometry and state source IDs. Source asset URLs in raw code are reference-only: icons must use native semantic symbols, never temporary URLs.
